package classes.exceptions;

public class StudentAlreadyThereException extends RuntimeException {
    public StudentAlreadyThereException() {
        super();
    }
}
