package classes.exceptions;

public class NoServiceOfTypeAndStar extends RuntimeException {
    public NoServiceOfTypeAndStar() {
        super();
    }
}
