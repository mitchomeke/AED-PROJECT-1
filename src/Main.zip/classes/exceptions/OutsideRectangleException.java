package classes.exceptions;
public class OutsideRectangleException extends RuntimeException {
    public OutsideRectangleException() {
        super();
    }
}
