package classes.exceptions;
public class InvalidBoundsException extends RuntimeException {
    public InvalidBoundsException() {
        super();
    }
}
