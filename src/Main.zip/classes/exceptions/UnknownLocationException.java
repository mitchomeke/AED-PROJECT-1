package classes.exceptions;

public class UnknownLocationException extends RuntimeException {
    public UnknownLocationException() {
        super();
    }
}
