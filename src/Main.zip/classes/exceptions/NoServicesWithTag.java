package classes.exceptions;

public class NoServicesWithTag extends RuntimeException {
    public NoServicesWithTag() {
        super();
    }
}
