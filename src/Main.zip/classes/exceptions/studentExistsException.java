package classes.exceptions;

public class studentExistsException extends RuntimeException {
    public studentExistsException() {
        super();
    }
}
