package classes.exceptions;

public class MoveNotAcceptableException extends RuntimeException {
    public MoveNotAcceptableException() {
        super();
    }
}
