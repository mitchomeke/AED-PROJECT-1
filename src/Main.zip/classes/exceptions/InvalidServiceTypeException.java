package classes.exceptions;
public class InvalidServiceTypeException extends RuntimeException {
    public InvalidServiceTypeException() {
        super();
    }
}
