package classes.exceptions;

public class StudentDoesNotExistsException extends RuntimeException {
    public StudentDoesNotExistsException() {
        super();
    }
}
