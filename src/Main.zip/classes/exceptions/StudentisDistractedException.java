package classes.exceptions;

public class StudentisDistractedException extends RuntimeException {
    public StudentisDistractedException() {
        super();
    }
}
