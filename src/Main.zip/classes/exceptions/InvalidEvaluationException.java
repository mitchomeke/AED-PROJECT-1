package classes.exceptions;

public class InvalidEvaluationException extends RuntimeException {
    public InvalidEvaluationException() {
        super();
    }
}
