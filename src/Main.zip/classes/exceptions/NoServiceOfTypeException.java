package classes.exceptions;

public class NoServiceOfTypeException extends RuntimeException {
    public NoServiceOfTypeException() {
        super();
    }
}
