package classes.exceptions;

public class EatingServiceIsFullException extends RuntimeException {
    public EatingServiceIsFullException() {
        super();
    }
}
