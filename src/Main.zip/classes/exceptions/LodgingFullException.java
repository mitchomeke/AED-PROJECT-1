package classes.exceptions;

public class LodgingFullException extends RuntimeException {
    public LodgingFullException() {
        super();
    }
}
