package classes.exceptions;
public class InvalidTicketPriceException extends RuntimeException {
    public InvalidTicketPriceException() {
        super();
    }
}
