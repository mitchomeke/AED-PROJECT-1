package classes.exceptions;
public class InvalidRoomException extends RuntimeException {
    public InvalidRoomException() {
        super();
    }
}
