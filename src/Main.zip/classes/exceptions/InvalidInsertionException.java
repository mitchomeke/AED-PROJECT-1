package classes.exceptions;

public class InvalidInsertionException extends RuntimeException {
    public InvalidInsertionException() {
        super();
    }
}
