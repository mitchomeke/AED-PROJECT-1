package classes.exceptions;

public class InvalidStudentTypeException extends RuntimeException {
    public InvalidStudentTypeException() {
        super();
    }
}
