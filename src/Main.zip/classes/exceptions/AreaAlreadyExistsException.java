package classes.exceptions;
public class AreaAlreadyExistsException extends RuntimeException {
    public AreaAlreadyExistsException() {
        super();
    }
}
