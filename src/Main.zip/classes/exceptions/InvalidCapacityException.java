package classes.exceptions;

public class InvalidCapacityException extends RuntimeException {
    public InvalidCapacityException() {
        super();
    }
}
