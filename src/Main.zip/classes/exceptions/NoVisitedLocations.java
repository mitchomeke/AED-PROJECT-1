package classes.exceptions;

public class NoVisitedLocations extends RuntimeException {
    public NoVisitedLocations() {
        super();
    }
}
