package classes.exceptions;

public class ServiceExistsException extends RuntimeException {
    public ServiceExistsException() {
        super();
    }
}
