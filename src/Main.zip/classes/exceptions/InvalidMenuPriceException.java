package classes.exceptions;
public class InvalidMenuPriceException extends RuntimeException {
    public InvalidMenuPriceException() {
        super();
    }
}
