package classes.exceptions;
public class BoundsNotDefinedException extends RuntimeException {
    public BoundsNotDefinedException() {
        super();
    }
}
