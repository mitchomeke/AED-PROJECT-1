package classes.exceptions;

public class ServiceNotValidException extends RuntimeException {
    public ServiceNotValidException() {
        super();
    }
}
