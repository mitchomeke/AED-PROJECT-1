package classes.exceptions;

public class AlreadyHomeException extends RuntimeException {
    public AlreadyHomeException() {
        super();
    }
}
