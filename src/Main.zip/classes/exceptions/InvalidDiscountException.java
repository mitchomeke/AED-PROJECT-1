package classes.exceptions;

public class InvalidDiscountException extends RuntimeException {
    public InvalidDiscountException() {
        super();
    }
}
