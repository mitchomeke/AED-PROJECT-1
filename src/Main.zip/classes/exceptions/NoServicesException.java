package classes.exceptions;

public class NoServicesException extends RuntimeException {
    public NoServicesException() {
        super();
    }
}
