package classes.exceptions;

public class LodgingDoesntExistException extends RuntimeException {
    public LodgingDoesntExistException() {
        super();
    }
}
