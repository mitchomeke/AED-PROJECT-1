package classes.exceptions;

public class ThriftyStudentException extends RuntimeException {
    public ThriftyStudentException() {
        super();
    }
}
