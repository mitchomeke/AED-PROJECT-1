package classes.exceptions;

public class NoStudentsException extends RuntimeException {
    public NoStudentsException() {
        super();
    }
}
